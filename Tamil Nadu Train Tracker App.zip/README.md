
  # Tamil Nadu Train Tracker App

  This is a code bundle for Tamil Nadu Train Tracker App. The original project is available at https://www.figma.com/design/nUIiZtye9WIuZ2Zm80F4Po/Tamil-Nadu-Train-Tracker-App.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  