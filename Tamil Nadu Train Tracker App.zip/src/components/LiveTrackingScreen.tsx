import { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { ArrowLeft, Navigation, Clock, MapPin, Zap, Info } from 'lucide-react';
import type { Train } from '../App';

interface LiveTrackingScreenProps {
  train: Train;
  onBack: () => void;
  onViewTimeline: () => void;
}

export function LiveTrackingScreen({ train, onBack, onViewTimeline }: LiveTrackingScreenProps) {
  const [currentSpeed, setCurrentSpeed] = useState(train.currentSpeed);
  const [lastUpdated, setLastUpdated] = useState('Just now');

  // Simulate live speed updates
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentSpeed((prev) => {
        const change = Math.random() * 10 - 5;
        return Math.max(60, Math.min(110, prev + change));
      });
      
      const seconds = Math.floor(Math.random() * 30);
      setLastUpdated(seconds === 0 ? 'Just now' : `${seconds}s ago`);
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  const progress = 65; // Example: 65% of journey completed

  return (
    <div className="h-screen bg-gray-50 flex flex-col">
      {/* Map View */}
      <div className="relative h-[55vh] bg-gradient-to-br from-blue-50 to-blue-100">
        {/* Map Background with Grid */}
        <svg className="absolute inset-0 w-full h-full opacity-20" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <pattern id="mapgrid" x="0" y="0" width="30" height="30" patternUnits="userSpaceOnUse">
              <path d="M 30 0 L 0 0 0 30" fill="none" stroke="#1A73E8" strokeWidth="0.5"/>
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#mapgrid)"/>
        </svg>

        {/* Tamil Nadu Map with Railway Route */}
        <svg className="absolute inset-0 w-full h-full" viewBox="0 0 400 600" xmlns="http://www.w3.org/2000/svg">
          {/* TN State Outline */}
          <path 
            d="M200 50 L280 80 L320 160 L310 260 L280 340 L220 420 L160 400 L110 340 L80 260 L80 160 L120 100 Z" 
            fill="white"
            fillOpacity="0.5"
            stroke="#1A73E8"
            strokeWidth="3"
            strokeDasharray="8,4"
          />
          
          {/* Railway Route Line */}
          <motion.path
            d="M200 100 L220 180 L200 260 L210 340 L200 380"
            fill="none"
            stroke="#1A73E8"
            strokeWidth="4"
            strokeLinecap="round"
            initial={{ pathLength: 0 }}
            animate={{ pathLength: 1 }}
            transition={{ duration: 2, ease: "easeInOut" }}
          />

          {/* Station Markers */}
          <circle cx="200" cy="100" r="8" fill="white" stroke="#1A73E8" strokeWidth="3"/>
          <circle cx="220" cy="180" r="6" fill="white" stroke="#1A73E8" strokeWidth="2"/>
          <circle cx="200" cy="260" r="6" fill="white" stroke="#1A73E8" strokeWidth="2"/>
          <circle cx="210" cy="340" r="6" fill="white" stroke="#1A73E8" strokeWidth="2"/>
          <circle cx="200" cy="380" r="8" fill="white" stroke="#1A73E8" strokeWidth="3"/>

          {/* Animated Train Position */}
          <motion.g
            animate={{ 
              y: [0, 10, 0],
            }}
            transition={{ 
              duration: 2,
              repeat: Infinity,
              ease: "easeInOut"
            }}
          >
            {/* Train Marker */}
            <circle 
              cx="200" 
              cy="260" 
              r="18" 
              fill={train.status === 'On Time' ? '#22C55E' : '#EF4444'}
              opacity="0.3"
            />
            <circle 
              cx="200" 
              cy="260" 
              r="12" 
              fill={train.status === 'On Time' ? '#22C55E' : '#EF4444'}
            />
            <path
              d="M195 258 L205 258 L205 262 L195 262 Z M197 255 L203 255 M197 265 L203 265"
              stroke="white"
              strokeWidth="1.5"
              strokeLinecap="round"
            />
          </motion.g>

          {/* Pulse Effect */}
          <motion.circle
            cx="200"
            cy="260"
            r="15"
            fill={train.status === 'On Time' ? '#22C55E' : '#EF4444'}
            initial={{ opacity: 0.5, scale: 1 }}
            animate={{ opacity: 0, scale: 2 }}
            transition={{ duration: 2, repeat: Infinity }}
          />
        </svg>

        {/* Top Header */}
        <div className="absolute top-0 left-0 right-0 bg-gradient-to-b from-black/30 to-transparent px-4 pt-12 pb-6">
          <div className="flex items-center justify-between">
            <button 
              onClick={onBack}
              className="text-white bg-white/20 backdrop-blur-sm hover:bg-white/30 rounded-full p-2 transition-colors"
            >
              <ArrowLeft size={24} />
            </button>
            <div className="flex gap-2">
              <div className="bg-white/20 backdrop-blur-sm px-3 py-1.5 rounded-full text-white text-sm flex items-center gap-1.5">
                <div className={`w-2 h-2 rounded-full animate-pulse ${train.status === 'On Time' ? 'bg-green-400' : 'bg-red-400'}`}/>
                Live
              </div>
              <button className="text-white bg-white/20 backdrop-blur-sm hover:bg-white/30 rounded-full p-2 transition-colors">
                <Navigation size={20} />
              </button>
            </div>
          </div>
        </div>

        {/* Speed Badge */}
        <motion.div 
          className="absolute top-32 right-4 bg-white rounded-2xl shadow-lg p-4 text-center"
          animate={{ scale: [1, 1.05, 1] }}
          transition={{ duration: 2, repeat: Infinity }}
        >
          <Zap className="text-yellow-500 mx-auto mb-1" size={20} />
          <div className="text-2xl text-gray-900">{Math.round(currentSpeed)}</div>
          <div className="text-xs text-gray-500">km/h</div>
        </motion.div>

        {/* Last Updated */}
        <div className="absolute bottom-4 left-4 bg-white/90 backdrop-blur-sm px-3 py-2 rounded-full text-xs text-gray-600 flex items-center gap-1.5">
          <Clock size={12} />
          Updated {lastUpdated}
        </div>
      </div>

      {/* Bottom Info Card */}
      <div className="flex-1 bg-white rounded-t-3xl -mt-6 relative z-10 shadow-2xl overflow-y-auto">
        <div className="px-6 pt-6 pb-8">
          {/* Drag Handle */}
          <div className="w-12 h-1.5 bg-gray-300 rounded-full mx-auto mb-6"/>

          {/* Train Info Header */}
          <div className="flex items-start gap-4 mb-6">
            <div className="w-14 h-14 bg-gradient-to-br from-[#1A73E8] to-[#0D47A1] rounded-2xl flex items-center justify-center flex-shrink-0">
              <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2">
                <rect x="3" y="8" width="18" height="12" rx="2"/>
                <path d="M3 12h18M7 8V5a2 2 0 0 1 2-2h6a2 2 0 0 1 2 2v3"/>
                <circle cx="8" cy="18" r="1"/>
                <circle cx="16" cy="18" r="1"/>
              </svg>
            </div>
            <div className="flex-1">
              <h2 className="text-gray-900 text-xl mb-1">
                {train.number} - {train.name}
              </h2>
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <MapPin size={14} />
                <span>{train.from}</span>
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <polyline points="9 18 15 12 9 6"/>
                </svg>
                <span>{train.to}</span>
              </div>
            </div>
          </div>

          {/* Status Badge */}
          <div className={`inline-flex items-center gap-2 px-4 py-2 rounded-full mb-6 ${
            train.status === 'On Time' 
              ? 'bg-green-50 text-green-700' 
              : 'bg-red-50 text-red-700'
          }`}>
            {train.status === 'On Time' ? (
              <>
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <polyline points="20 6 9 17 4 12"/>
                </svg>
                On Time
              </>
            ) : (
              <>
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <circle cx="12" cy="12" r="10"/>
                  <line x1="12" y1="8" x2="12" y2="12"/>
                  <line x1="12" y1="16" x2="12.01" y2="16"/>
                </svg>
                Delayed by {train.delay} minutes
              </>
            )}
          </div>

          {/* Progress Bar */}
          <div className="mb-6">
            <div className="flex items-center justify-between mb-2 text-sm">
              <span className="text-gray-600">Journey Progress</span>
              <span className="text-[#1A73E8]">{progress}%</span>
            </div>
            <div className="h-3 bg-gray-100 rounded-full overflow-hidden">
              <motion.div
                className={`h-full rounded-full ${train.status === 'On Time' ? 'bg-green-500' : 'bg-red-500'}`}
                initial={{ width: 0 }}
                animate={{ width: `${progress}%` }}
                transition={{ duration: 1, ease: "easeOut" }}
              />
            </div>
          </div>

          {/* Info Grid */}
          <div className="grid grid-cols-2 gap-4 mb-6">
            <div className="bg-gradient-to-br from-blue-50 to-blue-100 rounded-2xl p-4">
              <div className="text-sm text-gray-600 mb-1">Next Station</div>
              <div className="text-gray-900">{train.nextStation}</div>
            </div>
            <div className="bg-gradient-to-br from-purple-50 to-purple-100 rounded-2xl p-4">
              <div className="text-sm text-gray-600 mb-1">ETA</div>
              <div className="text-gray-900">{train.eta}</div>
            </div>
            <div className="bg-gradient-to-br from-green-50 to-green-100 rounded-2xl p-4">
              <div className="text-sm text-gray-600 mb-1">Distance Left</div>
              <div className="text-gray-900">{train.distanceRemaining} km</div>
            </div>
            <div className="bg-gradient-to-br from-orange-50 to-orange-100 rounded-2xl p-4">
              <div className="text-sm text-gray-600 mb-1">Avg Speed</div>
              <div className="text-gray-900">{Math.round(currentSpeed)} km/h</div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="space-y-3">
            <button 
              onClick={onViewTimeline}
              className="w-full bg-[#1A73E8] text-white py-4 rounded-2xl hover:bg-[#1557B0] transition-colors flex items-center justify-center gap-2"
            >
              <Clock size={20} />
              View Station Timeline
            </button>
            <button className="w-full bg-gray-100 text-gray-700 py-4 rounded-2xl hover:bg-gray-200 transition-colors flex items-center justify-center gap-2">
              <Info size={20} />
              Train Details & Schedule
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
