import { useState } from 'react';
import { motion } from 'motion/react';
import { Search, MapPin, Clock, TrendingUp } from 'lucide-react';
import type { Screen, Train } from '../App';

interface HomeScreenProps {
  onSearch: () => void;
  onNavigate: (screen: Screen) => void;
  onTrainSelect: (train: Train) => void;
}

export function HomeScreen({ onSearch, onNavigate, onTrainSelect }: HomeScreenProps) {
  const [searchQuery, setSearchQuery] = useState('');

  const recentTrains = [
    { number: '12635', name: 'Vaigai Express', route: 'Chennai → Madurai' },
    { number: '12621', name: 'Tamil Nadu Express', route: 'Chennai → New Delhi' },
    { number: '16127', name: 'Guruvayur Express', route: 'Chennai → Guruvayur' },
  ];

  const liveTrains = [
    {
      number: '12635',
      name: 'Vaigai Express',
      from: 'Chennai Egmore',
      to: 'Madurai Junction',
      status: 'On Time' as const,
      currentSpeed: 95,
      nextStation: 'Villupuram',
      distanceRemaining: 45,
      eta: '14:35',
      currentLat: 11.9416,
      currentLng: 79.8083,
    },
    {
      number: '12621',
      name: 'Tamil Nadu Express',
      from: 'Chennai Central',
      to: 'New Delhi',
      status: 'Delayed' as const,
      delay: 15,
      currentSpeed: 80,
      nextStation: 'Katpadi Junction',
      distanceRemaining: 32,
      eta: '12:50',
      currentLat: 12.9698,
      currentLng: 79.1566,
    },
  ];

  const handleSearch = () => {
    onSearch();
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#1A73E8] to-[#0D47A1] pb-20">
      {/* Header */}
      <div className="px-4 pt-12 pb-8">
        <motion.div
          initial={{ y: -20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.5 }}
        >
          <h1 className="text-white text-3xl mb-2">
            TN Train Tracker
          </h1>
          <p className="text-blue-100">Track trains in real-time</p>
        </motion.div>

        {/* Search Bar */}
        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.2, duration: 0.5 }}
          className="mt-6"
        >
          <div className="relative">
            <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
            <input
              type="text"
              placeholder="Enter Train Number / Train Name"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onClick={handleSearch}
              className="w-full pl-12 pr-4 py-4 rounded-2xl shadow-lg text-gray-900 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-300"
            />
          </div>
        </motion.div>
      </div>

      {/* Main Content */}
      <div className="px-4 space-y-6">
        {/* Tamil Nadu Map Preview */}
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ delay: 0.3, duration: 0.5 }}
          className="bg-white rounded-3xl p-6 shadow-xl"
        >
          <h2 className="text-gray-900 mb-4 flex items-center gap-2">
            <MapPin className="text-[#1A73E8]" size={20} />
            Live Trains in Tamil Nadu
          </h2>
          
          {/* Simplified Map Visualization */}
          <div className="relative h-48 bg-gradient-to-br from-blue-50 to-blue-100 rounded-2xl overflow-hidden">
            {/* Map Background Pattern */}
            <svg className="absolute inset-0 w-full h-full opacity-30" xmlns="http://www.w3.org/2000/svg">
              <defs>
                <pattern id="grid" x="0" y="0" width="20" height="20" patternUnits="userSpaceOnUse">
                  <path d="M 20 0 L 0 0 0 20" fill="none" stroke="#1A73E8" strokeWidth="0.5"/>
                </pattern>
              </defs>
              <rect width="100%" height="100%" fill="url(#grid)"/>
            </svg>

            {/* TN Map Outline */}
            <svg className="absolute inset-0 w-full h-full" viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
              <path 
                d="M100 20 L140 35 L160 70 L155 110 L140 145 L110 175 L80 170 L55 145 L40 110 L40 70 L60 40 Z" 
                fill="none"
                stroke="#1A73E8"
                strokeWidth="2"
                strokeDasharray="5,5"
              />
              
              {/* Animated Train Icons */}
              <motion.g
                animate={{ y: [0, -3, 0] }}
                transition={{ duration: 2, repeat: Infinity }}
              >
                <circle cx="90" cy="80" r="6" fill="#22C55E"/>
                <circle cx="90" cy="80" r="12" fill="#22C55E" opacity="0.3"/>
              </motion.g>
              
              <motion.g
                animate={{ y: [0, -3, 0] }}
                transition={{ duration: 2, repeat: Infinity, delay: 0.5 }}
              >
                <circle cx="120" cy="120" r="6" fill="#EF4444"/>
                <circle cx="120" cy="120" r="12" fill="#EF4444" opacity="0.3"/>
              </motion.g>
            </svg>

            {/* Stats */}
            <div className="absolute bottom-3 left-3 right-3 flex gap-2">
              <div className="flex-1 bg-white/90 backdrop-blur-sm rounded-lg px-3 py-2">
                <div className="text-xs text-gray-600">Active Trains</div>
                <div className="text-[#1A73E8]">127</div>
              </div>
              <div className="flex-1 bg-white/90 backdrop-blur-sm rounded-lg px-3 py-2">
                <div className="text-xs text-gray-600">On Time</div>
                <div className="text-green-600">98</div>
              </div>
              <div className="flex-1 bg-white/90 backdrop-blur-sm rounded-lg px-3 py-2">
                <div className="text-xs text-gray-600">Delayed</div>
                <div className="text-red-600">29</div>
              </div>
            </div>
          </div>

          <button 
            onClick={handleSearch}
            className="w-full mt-4 bg-[#1A73E8] text-white py-3 rounded-xl hover:bg-[#1557B0] transition-colors"
          >
            Track Live Location
          </button>
        </motion.div>

        {/* Recent Searches */}
        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.4, duration: 0.5 }}
          className="bg-white rounded-3xl p-6 shadow-xl"
        >
          <h2 className="text-gray-900 mb-4 flex items-center gap-2">
            <Clock className="text-[#1A73E8]" size={20} />
            Recent Searches
          </h2>
          
          <div className="space-y-3">
            {recentTrains.map((train, index) => (
              <button
                key={index}
                onClick={() => {
                  const trainData = liveTrains.find(t => t.number === train.number);
                  if (trainData) onTrainSelect(trainData);
                }}
                className="w-full flex items-center gap-3 p-3 hover:bg-gray-50 rounded-xl transition-colors"
              >
                <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#1A73E8" strokeWidth="2">
                    <rect x="3" y="8" width="18" height="12" rx="2"/>
                    <path d="M3 12h18M7 8V5a2 2 0 0 1 2-2h6a2 2 0 0 1 2 2v3"/>
                    <circle cx="8" cy="18" r="1"/>
                    <circle cx="16" cy="18" r="1"/>
                  </svg>
                </div>
                <div className="flex-1 text-left">
                  <div className="text-gray-900">{train.number} - {train.name}</div>
                  <div className="text-sm text-gray-500">{train.route}</div>
                </div>
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#9CA3AF" strokeWidth="2">
                  <polyline points="9 18 15 12 9 6"/>
                </svg>
              </button>
            ))}
          </div>
        </motion.div>

        {/* Quick Stats */}
        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.5, duration: 0.5 }}
          className="bg-white rounded-3xl p-6 shadow-xl"
        >
          <h2 className="text-gray-900 mb-4 flex items-center gap-2">
            <TrendingUp className="text-[#1A73E8]" size={20} />
            Live Updates
          </h2>
          
          <div className="space-y-3">
            <div className="flex items-start gap-3 p-3 bg-green-50 rounded-xl">
              <div className="w-2 h-2 bg-green-500 rounded-full mt-2 animate-pulse"/>
              <div className="flex-1">
                <div className="text-sm text-gray-900">12635 Vaigai Express</div>
                <div className="text-xs text-gray-600">Running on time • Next: Villupuram</div>
              </div>
            </div>
            <div className="flex items-start gap-3 p-3 bg-orange-50 rounded-xl">
              <div className="w-2 h-2 bg-orange-500 rounded-full mt-2 animate-pulse"/>
              <div className="flex-1">
                <div className="text-sm text-gray-900">12621 Tamil Nadu Express</div>
                <div className="text-xs text-gray-600">Delayed by 15 mins • Near Katpadi</div>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
