import { motion } from 'motion/react';
import { Bell, MapPin, Clock, AlertTriangle, Info, CheckCircle } from 'lucide-react';

interface AlertsProps {
  onBack: () => void;
}

interface Alert {
  id: string;
  type: 'approaching' | 'delay' | 'platform' | 'info';
  title: string;
  message: string;
  trainNumber: string;
  time: string;
  isNew: boolean;
}

export function Alerts({ onBack }: AlertsProps) {
  const alerts: Alert[] = [
    {
      id: '1',
      type: 'approaching',
      title: 'Train Approaching Station',
      message: '12635 Vaigai Express is approaching Villupuram Junction. Expected arrival in 5 minutes.',
      trainNumber: '12635',
      time: '2 min ago',
      isNew: true,
    },
    {
      id: '2',
      type: 'platform',
      title: 'Platform Change',
      message: '12621 Tamil Nadu Express platform changed from 3 to 5 at Katpadi Junction.',
      trainNumber: '12621',
      time: '15 min ago',
      isNew: true,
    },
    {
      id: '3',
      type: 'delay',
      title: 'Delay Alert',
      message: '12676 Kovai Express is delayed by 15 minutes due to signal clearance.',
      trainNumber: '12676',
      time: '28 min ago',
      isNew: true,
    },
    {
      id: '4',
      type: 'info',
      title: 'Train Departed',
      message: '12635 Vaigai Express has departed from Chengalpattu on time.',
      trainNumber: '12635',
      time: '1 hour ago',
      isNew: false,
    },
    {
      id: '5',
      type: 'approaching',
      title: 'Next Station Alert',
      message: '16127 Guruvayur Express will reach Coimbatore Junction in 20 minutes.',
      trainNumber: '16127',
      time: '1 hour ago',
      isNew: false,
    },
  ];

  const getAlertIcon = (type: Alert['type']) => {
    switch (type) {
      case 'approaching':
        return <MapPin className="text-blue-600" size={20} />;
      case 'delay':
        return <AlertTriangle className="text-orange-600" size={20} />;
      case 'platform':
        return <Info className="text-purple-600" size={20} />;
      case 'info':
        return <CheckCircle className="text-green-600" size={20} />;
    }
  };

  const getAlertColor = (type: Alert['type']) => {
    switch (type) {
      case 'approaching':
        return 'from-blue-50 to-blue-100';
      case 'delay':
        return 'from-orange-50 to-orange-100';
      case 'platform':
        return 'from-purple-50 to-purple-100';
      case 'info':
        return 'from-green-50 to-green-100';
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 pb-20">
      {/* Header */}
      <div className="bg-gradient-to-r from-[#1A73E8] to-[#0D47A1] px-4 pt-12 pb-6 sticky top-0 z-10 shadow-lg">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-white text-2xl mb-1">Notifications</h1>
            <p className="text-blue-100 text-sm">Live updates & alerts</p>
          </div>
          <div className="relative">
            <Bell className="text-white" size={24} />
            <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
              3
            </span>
          </div>
        </div>

        {/* Filter Tabs */}
        <div className="flex gap-2 overflow-x-auto pb-2">
          <button className="px-4 py-2 bg-white text-[#1A73E8] rounded-full text-sm whitespace-nowrap">
            All
          </button>
          <button className="px-4 py-2 bg-white/20 text-white rounded-full text-sm whitespace-nowrap hover:bg-white/30 transition-colors">
            Approaching
          </button>
          <button className="px-4 py-2 bg-white/20 text-white rounded-full text-sm whitespace-nowrap hover:bg-white/30 transition-colors">
            Delays
          </button>
          <button className="px-4 py-2 bg-white/20 text-white rounded-full text-sm whitespace-nowrap hover:bg-white/30 transition-colors">
            Platform
          </button>
        </div>
      </div>

      {/* Alerts List */}
      <div className="px-4 py-6 space-y-4">
        {alerts.map((alert, index) => (
          <motion.div
            key={alert.id}
            initial={{ x: -20, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ delay: index * 0.1, duration: 0.3 }}
            className={`bg-gradient-to-br ${getAlertColor(alert.type)} rounded-2xl p-4 shadow-md relative overflow-hidden`}
          >
            {/* New Badge */}
            {alert.isNew && (
              <div className="absolute top-4 right-4">
                <span className="bg-red-500 text-white text-xs px-2 py-1 rounded-full">
                  New
                </span>
              </div>
            )}

            {/* Alert Header */}
            <div className="flex items-start gap-3 mb-3">
              <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center flex-shrink-0 shadow-sm">
                {getAlertIcon(alert.type)}
              </div>
              <div className="flex-1 pr-12">
                <h3 className="text-gray-900 mb-1">{alert.title}</h3>
                <div className="flex items-center gap-2 text-sm">
                  <span className="bg-white/70 px-2 py-0.5 rounded text-gray-700">
                    {alert.trainNumber}
                  </span>
                  <span className="text-gray-600 text-xs flex items-center gap-1">
                    <Clock size={12} />
                    {alert.time}
                  </span>
                </div>
              </div>
            </div>

            {/* Alert Message */}
            <p className="text-sm text-gray-700 leading-relaxed pl-13">
              {alert.message}
            </p>

            {/* Action Buttons */}
            <div className="flex gap-2 mt-4 pl-13">
              <button className="text-sm text-[#1A73E8] hover:underline">
                View Train
              </button>
              <span className="text-gray-300">•</span>
              <button className="text-sm text-gray-600 hover:underline">
                Dismiss
              </button>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Notification Settings */}
      <div className="px-4 pb-6">
        <div className="bg-white rounded-2xl p-6 shadow-md">
          <h3 className="text-gray-900 mb-4">Notification Settings</h3>
          
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-sm text-gray-900">Train Approaching</div>
                <div className="text-xs text-gray-500">Alert when train nears station</div>
              </div>
              <label className="relative inline-block w-12 h-6">
                <input type="checkbox" className="peer sr-only" defaultChecked />
                <span className="absolute inset-0 bg-gray-200 rounded-full peer-checked:bg-[#1A73E8] transition-colors"/>
                <span className="absolute left-1 top-1 w-4 h-4 bg-white rounded-full transition-transform peer-checked:translate-x-6"/>
              </label>
            </div>

            <div className="flex items-center justify-between">
              <div>
                <div className="text-sm text-gray-900">Delay Alerts</div>
                <div className="text-xs text-gray-500">Notify about delays</div>
              </div>
              <label className="relative inline-block w-12 h-6">
                <input type="checkbox" className="peer sr-only" defaultChecked />
                <span className="absolute inset-0 bg-gray-200 rounded-full peer-checked:bg-[#1A73E8] transition-colors"/>
                <span className="absolute left-1 top-1 w-4 h-4 bg-white rounded-full transition-transform peer-checked:translate-x-6"/>
              </label>
            </div>

            <div className="flex items-center justify-between">
              <div>
                <div className="text-sm text-gray-900">Platform Changes</div>
                <div className="text-xs text-gray-500">Alert on platform updates</div>
              </div>
              <label className="relative inline-block w-12 h-6">
                <input type="checkbox" className="peer sr-only" defaultChecked />
                <span className="absolute inset-0 bg-gray-200 rounded-full peer-checked:bg-[#1A73E8] transition-colors"/>
                <span className="absolute left-1 top-1 w-4 h-4 bg-white rounded-full transition-transform peer-checked:translate-x-6"/>
              </label>
            </div>

            <div className="flex items-center justify-between">
              <div>
                <div className="text-sm text-gray-900">General Updates</div>
                <div className="text-xs text-gray-500">System notifications</div>
              </div>
              <label className="relative inline-block w-12 h-6">
                <input type="checkbox" className="peer sr-only" />
                <span className="absolute inset-0 bg-gray-200 rounded-full peer-checked:bg-[#1A73E8] transition-colors"/>
                <span className="absolute left-1 top-1 w-4 h-4 bg-white rounded-full transition-transform peer-checked:translate-x-6"/>
              </label>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
