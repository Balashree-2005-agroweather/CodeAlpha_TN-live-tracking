import { useState } from 'react';
import { motion } from 'motion/react';
import { ArrowLeft, Search, MapPin } from 'lucide-react';
import type { Train } from '../App';

interface SearchResultsProps {
  onBack: () => void;
  onTrainSelect: (train: Train) => void;
}

export function SearchResults({ onBack, onTrainSelect }: SearchResultsProps) {
  const [searchQuery, setSearchQuery] = useState('');

  const trains: Train[] = [
    {
      number: '12635',
      name: 'Vaigai Express',
      from: 'Chennai Egmore',
      to: 'Madurai Junction',
      status: 'On Time',
      currentSpeed: 95,
      nextStation: 'Villupuram',
      distanceRemaining: 45,
      eta: '14:35',
      currentLat: 11.9416,
      currentLng: 79.8083,
    },
    {
      number: '12621',
      name: 'Tamil Nadu Express',
      from: 'Chennai Central',
      to: 'New Delhi',
      status: 'Delayed',
      delay: 15,
      currentSpeed: 80,
      nextStation: 'Katpadi Junction',
      distanceRemaining: 32,
      eta: '12:50',
      currentLat: 12.9698,
      currentLng: 79.1566,
    },
    {
      number: '12633',
      name: 'Kanyakumari Express',
      from: 'Chennai Egmore',
      to: 'Kanyakumari',
      status: 'On Time',
      currentSpeed: 88,
      nextStation: 'Tirunelveli',
      distanceRemaining: 78,
      eta: '18:20',
      currentLat: 8.7139,
      currentLng: 77.7567,
    },
    {
      number: '16127',
      name: 'Guruvayur Express',
      from: 'Chennai Central',
      to: 'Guruvayur',
      status: 'On Time',
      currentSpeed: 92,
      nextStation: 'Coimbatore',
      distanceRemaining: 112,
      eta: '16:45',
      currentLat: 11.0168,
      currentLng: 76.9558,
    },
    {
      number: '12676',
      name: 'Kovai Express',
      from: 'Chennai Central',
      to: 'Coimbatore',
      status: 'Delayed',
      delay: 8,
      currentSpeed: 75,
      nextStation: 'Erode',
      distanceRemaining: 25,
      eta: '15:15',
      currentLat: 11.3410,
      currentLng: 77.7172,
    },
    {
      number: '12694',
      name: 'Pearl City Express',
      from: 'Chennai Central',
      to: 'Tuticorin',
      status: 'On Time',
      currentSpeed: 90,
      nextStation: 'Madurai',
      distanceRemaining: 52,
      eta: '17:30',
      currentLat: 9.9252,
      currentLng: 78.1198,
    },
  ];

  const filteredTrains = searchQuery
    ? trains.filter(
        (train) =>
          train.number.includes(searchQuery) ||
          train.name.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : trains;

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-[#1A73E8] px-4 pt-12 pb-6">
        <div className="flex items-center gap-4 mb-6">
          <button 
            onClick={onBack}
            className="text-white hover:bg-white/10 rounded-full p-2 transition-colors"
          >
            <ArrowLeft size={24} />
          </button>
          <h1 className="text-white text-2xl flex-1">Search Trains</h1>
        </div>

        {/* Search Bar */}
        <div className="relative">
          <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
          <input
            type="text"
            placeholder="Train Number / Name"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-12 pr-4 py-4 rounded-2xl shadow-lg text-gray-900 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-300"
            autoFocus
          />
        </div>
      </div>

      {/* Results */}
      <div className="px-4 py-6 space-y-3 pb-20">
        <div className="flex items-center justify-between mb-2">
          <p className="text-sm text-gray-600">
            {filteredTrains.length} trains found
          </p>
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 bg-green-500 rounded-full"/>
            <span className="text-xs text-gray-600">Live</span>
          </div>
        </div>

        {filteredTrains.map((train, index) => (
          <motion.button
            key={train.number}
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: index * 0.05, duration: 0.3 }}
            onClick={() => onTrainSelect(train)}
            className="w-full bg-white rounded-2xl p-4 shadow-md hover:shadow-lg transition-all text-left"
          >
            {/* Header */}
            <div className="flex items-start justify-between mb-3">
              <div className="flex items-start gap-3">
                <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center flex-shrink-0">
                  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#1A73E8" strokeWidth="2">
                    <rect x="3" y="8" width="18" height="12" rx="2"/>
                    <path d="M3 12h18M7 8V5a2 2 0 0 1 2-2h6a2 2 0 0 1 2 2v3"/>
                    <circle cx="8" cy="18" r="1"/>
                    <circle cx="16" cy="18" r="1"/>
                  </svg>
                </div>
                <div>
                  <div className="text-gray-900 mb-1">
                    {train.number} - {train.name}
                  </div>
                  <div className="flex items-center gap-2 text-sm text-gray-600">
                    <MapPin size={14} />
                    <span>{train.from}</span>
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                      <polyline points="9 18 15 12 9 6"/>
                    </svg>
                    <span>{train.to}</span>
                  </div>
                </div>
              </div>
              
              {/* Live Indicator */}
              <div className="flex items-center gap-1.5">
                <div className={`w-2 h-2 rounded-full animate-pulse ${train.status === 'On Time' ? 'bg-green-500' : 'bg-red-500'}`}/>
                <span className="text-xs text-gray-500">Live</span>
              </div>
            </div>

            {/* Status Bar */}
            <div className="flex items-center justify-between pt-3 border-t border-gray-100">
              <div className="flex items-center gap-4">
                <div>
                  <div className="text-xs text-gray-500">Status</div>
                  <div className={`text-sm ${train.status === 'On Time' ? 'text-green-600' : 'text-red-600'}`}>
                    {train.status === 'On Time' ? '✓ On Time' : `⚠ Delayed ${train.delay}m`}
                  </div>
                </div>
                <div>
                  <div className="text-xs text-gray-500">Next Station</div>
                  <div className="text-sm text-gray-900">{train.nextStation}</div>
                </div>
              </div>
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#1A73E8" strokeWidth="2">
                <polyline points="9 18 15 12 9 6"/>
              </svg>
            </div>
          </motion.button>
        ))}
      </div>
    </div>
  );
}
