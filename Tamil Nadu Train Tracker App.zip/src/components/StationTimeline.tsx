import { motion } from 'motion/react';
import { ArrowLeft, MapPin, Clock, CheckCircle, AlertCircle, Circle } from 'lucide-react';
import type { Train } from '../App';

interface StationTimelineProps {
  train: Train;
  onBack: () => void;
}

interface Station {
  name: string;
  arrivalTime: string;
  departureTime: string;
  expectedArrival: string;
  expectedDeparture: string;
  platform: string;
  status: 'completed' | 'current' | 'delayed' | 'upcoming';
  distance: number;
}

export function StationTimeline({ train, onBack }: StationTimelineProps) {
  const stations: Station[] = [
    {
      name: 'Chennai Egmore',
      arrivalTime: '--',
      departureTime: '06:00',
      expectedArrival: '--',
      expectedDeparture: '06:00',
      platform: '5',
      status: 'completed',
      distance: 0,
    },
    {
      name: 'Tambaram',
      arrivalTime: '06:25',
      departureTime: '06:27',
      expectedArrival: '06:25',
      expectedDeparture: '06:27',
      platform: '3',
      status: 'completed',
      distance: 27,
    },
    {
      name: 'Chengalpattu',
      arrivalTime: '06:45',
      departureTime: '06:47',
      expectedArrival: '06:45',
      expectedDeparture: '06:47',
      platform: '2',
      status: 'completed',
      distance: 56,
    },
    {
      name: 'Villupuram',
      arrivalTime: '08:15',
      departureTime: '08:20',
      expectedArrival: '08:15',
      expectedDeparture: '08:20',
      platform: '1',
      status: 'current',
      distance: 158,
    },
    {
      name: 'Virudhachalam',
      arrivalTime: '--',
      departureTime: '--',
      expectedArrival: '09:05',
      expectedDeparture: '09:07',
      platform: '2',
      status: 'upcoming',
      distance: 227,
    },
    {
      name: 'Trichy',
      arrivalTime: '--',
      departureTime: '--',
      expectedArrival: '10:30',
      expectedDeparture: '10:35',
      platform: '4',
      status: 'upcoming',
      distance: 321,
    },
    {
      name: 'Dindigul',
      arrivalTime: '--',
      departureTime: '--',
      expectedArrival: '12:15',
      expectedDeparture: '12:17',
      platform: '1',
      status: 'upcoming',
      distance: 421,
    },
    {
      name: 'Madurai Junction',
      arrivalTime: '--',
      departureTime: '--',
      expectedArrival: '13:00',
      expectedDeparture: '--',
      platform: '3',
      status: 'upcoming',
      distance: 497,
    },
  ];

  return (
    <div className="min-h-screen bg-gray-50 pb-20">
      {/* Header */}
      <div className="bg-gradient-to-r from-[#1A73E8] to-[#0D47A1] px-4 pt-12 pb-6 sticky top-0 z-10 shadow-lg">
        <div className="flex items-center gap-4 mb-4">
          <button 
            onClick={onBack}
            className="text-white hover:bg-white/10 rounded-full p-2 transition-colors"
          >
            <ArrowLeft size={24} />
          </button>
          <div className="flex-1">
            <h1 className="text-white text-xl">Station Timeline</h1>
            <p className="text-blue-100 text-sm">{train.number} - {train.name}</p>
          </div>
        </div>

        {/* Status Summary */}
        <div className="grid grid-cols-3 gap-3 mt-4">
          <div className="bg-white/10 backdrop-blur-sm rounded-xl p-3">
            <div className="text-blue-100 text-xs mb-1">Completed</div>
            <div className="text-white">3 stations</div>
          </div>
          <div className="bg-white/10 backdrop-blur-sm rounded-xl p-3">
            <div className="text-blue-100 text-xs mb-1">Current</div>
            <div className="text-white">Villupuram</div>
          </div>
          <div className="bg-white/10 backdrop-blur-sm rounded-xl p-3">
            <div className="text-blue-100 text-xs mb-1">Remaining</div>
            <div className="text-white">4 stations</div>
          </div>
        </div>
      </div>

      {/* Timeline */}
      <div className="px-4 py-6">
        <div className="relative">
          {/* Vertical Line */}
          <div className="absolute left-[23px] top-0 bottom-0 w-0.5 bg-gray-200"/>

          {/* Stations */}
          <div className="space-y-6">
            {stations.map((station, index) => (
              <motion.div
                key={index}
                initial={{ x: -20, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                transition={{ delay: index * 0.1, duration: 0.3 }}
                className="relative"
              >
                {/* Timeline Dot */}
                <div className="absolute left-0 top-4">
                  {station.status === 'completed' && (
                    <div className="w-12 h-12 bg-green-500 rounded-full flex items-center justify-center shadow-lg">
                      <CheckCircle className="text-white" size={24} />
                    </div>
                  )}
                  {station.status === 'current' && (
                    <motion.div 
                      className="relative"
                      animate={{ scale: [1, 1.1, 1] }}
                      transition={{ duration: 2, repeat: Infinity }}
                    >
                      <div className="w-12 h-12 bg-[#1A73E8] rounded-full flex items-center justify-center shadow-lg">
                        <MapPin className="text-white" size={24} />
                      </div>
                      <div className="absolute inset-0 bg-[#1A73E8] rounded-full animate-ping opacity-75"/>
                    </motion.div>
                  )}
                  {station.status === 'delayed' && (
                    <div className="w-12 h-12 bg-orange-500 rounded-full flex items-center justify-center shadow-lg">
                      <AlertCircle className="text-white" size={24} />
                    </div>
                  )}
                  {station.status === 'upcoming' && (
                    <div className="w-12 h-12 bg-gray-200 rounded-full flex items-center justify-center shadow-md">
                      <Circle className="text-gray-400" size={24} />
                    </div>
                  )}
                </div>

                {/* Station Card */}
                <div className={`ml-16 bg-white rounded-2xl p-4 shadow-md ${
                  station.status === 'current' ? 'ring-2 ring-[#1A73E8]' : ''
                }`}>
                  {/* Station Name & Platform */}
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <h3 className="text-gray-900 mb-1">{station.name}</h3>
                      <div className="flex items-center gap-3 text-sm text-gray-600">
                        <span>{station.distance} km</span>
                        <span>•</span>
                        <span>Platform {station.platform}</span>
                      </div>
                    </div>
                    {station.status === 'current' && (
                      <span className="bg-blue-100 text-[#1A73E8] text-xs px-3 py-1 rounded-full">
                        Current
                      </span>
                    )}
                  </div>

                  {/* Timings */}
                  <div className="grid grid-cols-2 gap-4 pt-3 border-t border-gray-100">
                    <div>
                      <div className="flex items-center gap-1.5 text-xs text-gray-500 mb-1">
                        <Clock size={12} />
                        Arrival
                      </div>
                      <div className="text-gray-900">
                        {station.arrivalTime !== '--' ? (
                          <div className="flex items-center gap-2">
                            <span>{station.arrivalTime}</span>
                            {station.status === 'completed' && (
                              <span className="text-green-600 text-xs">✓</span>
                            )}
                          </div>
                        ) : (
                          <span className="text-gray-400">{station.expectedArrival}</span>
                        )}
                      </div>
                    </div>
                    <div>
                      <div className="flex items-center gap-1.5 text-xs text-gray-500 mb-1">
                        <Clock size={12} />
                        Departure
                      </div>
                      <div className="text-gray-900">
                        {station.departureTime !== '--' ? (
                          <div className="flex items-center gap-2">
                            <span>{station.departureTime}</span>
                            {station.status === 'completed' && (
                              <span className="text-green-600 text-xs">✓</span>
                            )}
                          </div>
                        ) : (
                          <span className="text-gray-400">{station.expectedDeparture}</span>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Status Message */}
                  {station.status === 'current' && (
                    <div className="mt-3 pt-3 border-t border-gray-100">
                      <div className="flex items-center gap-2 text-sm text-[#1A73E8]">
                        <div className="w-2 h-2 bg-[#1A73E8] rounded-full animate-pulse"/>
                        Train is currently at this station
                      </div>
                    </div>
                  )}
                  {station.status === 'completed' && (
                    <div className="mt-3 pt-3 border-t border-gray-100">
                      <div className="text-xs text-green-600">
                        ✓ Departed on time
                      </div>
                    </div>
                  )}
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Journey Summary */}
        <div className="mt-8 bg-gradient-to-br from-blue-50 to-purple-50 rounded-2xl p-6">
          <h3 className="text-gray-900 mb-4">Journey Summary</h3>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <div className="text-sm text-gray-600 mb-1">Total Distance</div>
              <div className="text-gray-900">497 km</div>
            </div>
            <div>
              <div className="text-sm text-gray-600 mb-1">Total Duration</div>
              <div className="text-gray-900">7h 0m</div>
            </div>
            <div>
              <div className="text-sm text-gray-600 mb-1">Avg Speed</div>
              <div className="text-gray-900">{train.currentSpeed} km/h</div>
            </div>
            <div>
              <div className="text-sm text-gray-600 mb-1">Status</div>
              <div className={train.status === 'On Time' ? 'text-green-600' : 'text-red-600'}>
                {train.status}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
