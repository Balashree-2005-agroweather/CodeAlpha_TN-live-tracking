import { motion } from 'motion/react';

export function SplashScreen() {
  return (
    <div className="h-screen bg-gradient-to-br from-[#1A73E8] to-[#0D47A1] flex flex-col items-center justify-center relative overflow-hidden">
      {/* Animated Background Pattern */}
      <div className="absolute inset-0 opacity-10">
        <svg className="w-full h-full" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <pattern id="tracks" x="0" y="0" width="40" height="40" patternUnits="userSpaceOnUse">
              <line x1="0" y1="20" x2="40" y2="20" stroke="white" strokeWidth="1"/>
              <line x1="0" y1="24" x2="40" y2="24" stroke="white" strokeWidth="1"/>
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#tracks)"/>
        </svg>
      </div>

      {/* Tamil Nadu Map Outline with Train */}
      <motion.div
        initial={{ scale: 0.5, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 0.8, ease: "easeOut" }}
        className="relative z-10"
      >
        {/* Simplified Tamil Nadu Map Shape */}
        <svg width="180" height="220" viewBox="0 0 180 220" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path 
            d="M90 10 L140 30 L160 70 L155 110 L140 150 L120 180 L90 210 L60 200 L40 170 L30 130 L25 90 L35 50 L60 25 Z" 
            fill="white" 
            fillOpacity="0.2"
            stroke="white"
            strokeWidth="3"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          
          {/* Animated Train Icon on Map */}
          <motion.g
            initial={{ y: 0 }}
            animate={{ y: [0, 80, 160] }}
            transition={{ duration: 2, ease: "linear", repeat: Infinity }}
          >
            <circle cx="80" cy="40" r="8" fill="#FFD700"/>
            <rect x="70" y="35" width="20" height="12" rx="2" fill="#FFD700"/>
            <circle cx="75" cy="50" r="2" fill="white"/>
            <circle cx="85" cy="50" r="2" fill="white"/>
          </motion.g>
        </svg>
      </motion.div>

      {/* Logo and Title */}
      <motion.div
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.3, duration: 0.6 }}
        className="mt-8 text-center relative z-10"
      >
        <h1 className="text-white text-4xl mb-2 tracking-tight">
          TN Train Tracker
        </h1>
        <p className="text-blue-100 text-lg">
          Live Train Location Across Tamil Nadu
        </p>
      </motion.div>

      {/* Loading Indicator */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.8, duration: 0.5 }}
        className="mt-12 relative z-10"
      >
        <div className="flex gap-2">
          <motion.div
            animate={{ scale: [1, 1.2, 1] }}
            transition={{ duration: 0.8, repeat: Infinity, delay: 0 }}
            className="w-2 h-2 bg-white rounded-full"
          />
          <motion.div
            animate={{ scale: [1, 1.2, 1] }}
            transition={{ duration: 0.8, repeat: Infinity, delay: 0.2 }}
            className="w-2 h-2 bg-white rounded-full"
          />
          <motion.div
            animate={{ scale: [1, 1.2, 1] }}
            transition={{ duration: 0.8, repeat: Infinity, delay: 0.4 }}
            className="w-2 h-2 bg-white rounded-full"
          />
        </div>
      </motion.div>

      {/* Version */}
      <motion.p
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1, duration: 0.5 }}
        className="absolute bottom-8 text-blue-100 text-sm"
      >
        Version 1.0.0
      </motion.p>
    </div>
  );
}
