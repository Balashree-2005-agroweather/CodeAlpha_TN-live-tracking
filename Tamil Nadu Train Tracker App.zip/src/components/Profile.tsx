import { motion } from 'motion/react';
import { ArrowLeft, User, Train, Bell, Moon, Globe, HelpCircle, Shield, LogOut, ChevronRight } from 'lucide-react';
import { Screen } from '../App';
import { useState } from 'react';

interface ProfileProps {
  onNavigate: (screen: Screen) => void;
}

export function Profile({ onNavigate }: ProfileProps) {
  const [darkMode, setDarkMode] = useState(false);
  const [notifications, setNotifications] = useState(true);
  const [language, setLanguage] = useState('English');

  const savedTrains = [
    { number: '12164', name: 'Chennai Express' },
    { number: '12676', name: 'Kovai Express' },
    { number: '12638', name: 'Pandian Express' }
  ];

  return (
    <div className="h-full flex flex-col bg-gray-50 pb-20">
      {/* Header */}
      <div className="bg-gradient-to-br from-[#1A73E8] to-[#0D47A1] px-6 pt-12 pb-16 shadow-lg">
        <div className="flex items-center gap-3 mb-8">
          <button
            onClick={() => onNavigate('home')}
            className="text-white"
          >
            <ArrowLeft className="w-6 h-6" />
          </button>
          <h1 className="text-white text-xl">Profile</h1>
        </div>

        {/* User Info */}
        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.4 }}
          className="flex items-center gap-4"
        >
          <div className="w-20 h-20 bg-white rounded-full flex items-center justify-center shadow-lg">
            <User className="w-10 h-10 text-[#1A73E8]" />
          </div>
          <div>
            <h2 className="text-white text-xl mb-1">Railway User</h2>
            <p className="text-white/80 text-sm">user@example.com</p>
          </div>
        </motion.div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto px-6 -mt-6">
        {/* Saved Trains */}
        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.1, duration: 0.4 }}
          className="bg-white rounded-xl p-4 shadow-md mb-4"
        >
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <Train className="w-5 h-5 text-[#1A73E8]" />
              <h3 className="text-gray-800">Saved Trains</h3>
            </div>
            <span className="text-xs text-gray-500">{savedTrains.length} trains</span>
          </div>

          <div className="space-y-2">
            {savedTrains.map((train, index) => (
              <div
                key={train.number}
                className="flex items-center justify-between py-2 px-3 bg-gray-50 rounded-lg"
              >
                <div>
                  <div className="text-sm text-[#1A73E8]">{train.number}</div>
                  <div className="text-xs text-gray-600">{train.name}</div>
                </div>
                <button className="text-gray-400 hover:text-gray-600">
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        </motion.div>

        {/* Settings */}
        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.2, duration: 0.4 }}
          className="bg-white rounded-xl p-4 shadow-md mb-4"
        >
          <h3 className="text-gray-800 mb-3">Settings</h3>

          <div className="space-y-3">
            {/* Notifications */}
            <div className="flex items-center justify-between py-2">
              <div className="flex items-center gap-3">
                <Bell className="w-5 h-5 text-gray-600" />
                <span className="text-sm text-gray-700">Notifications</span>
              </div>
              <button
                onClick={() => setNotifications(!notifications)}
                className={`w-12 h-6 rounded-full transition-colors ${
                  notifications ? 'bg-[#1A73E8]' : 'bg-gray-300'
                }`}
              >
                <div className={`w-5 h-5 bg-white rounded-full shadow-md transition-transform ${
                  notifications ? 'translate-x-6' : 'translate-x-0.5'
                }`} />
              </button>
            </div>

            {/* Dark Mode */}
            <div className="flex items-center justify-between py-2">
              <div className="flex items-center gap-3">
                <Moon className="w-5 h-5 text-gray-600" />
                <span className="text-sm text-gray-700">Dark Mode</span>
              </div>
              <button
                onClick={() => setDarkMode(!darkMode)}
                className={`w-12 h-6 rounded-full transition-colors ${
                  darkMode ? 'bg-[#1A73E8]' : 'bg-gray-300'
                }`}
              >
                <div className={`w-5 h-5 bg-white rounded-full shadow-md transition-transform ${
                  darkMode ? 'translate-x-6' : 'translate-x-0.5'
                }`} />
              </button>
            </div>

            {/* Language */}
            <div className="flex items-center justify-between py-2">
              <div className="flex items-center gap-3">
                <Globe className="w-5 h-5 text-gray-600" />
                <span className="text-sm text-gray-700">Language</span>
              </div>
              <select
                value={language}
                onChange={(e) => setLanguage(e.target.value)}
                className="text-sm text-gray-700 bg-gray-50 px-3 py-1 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1A73E8]"
              >
                <option>English</option>
                <option>தமிழ் (Tamil)</option>
              </select>
            </div>
          </div>
        </motion.div>

        {/* Other Options */}
        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.3, duration: 0.4 }}
          className="bg-white rounded-xl p-4 shadow-md mb-4"
        >
          <div className="space-y-1">
            <button className="w-full flex items-center justify-between py-3 px-2 hover:bg-gray-50 rounded-lg transition-colors">
              <div className="flex items-center gap-3">
                <HelpCircle className="w-5 h-5 text-gray-600" />
                <span className="text-sm text-gray-700">Help & Support</span>
              </div>
              <ChevronRight className="w-4 h-4 text-gray-400" />
            </button>

            <button className="w-full flex items-center justify-between py-3 px-2 hover:bg-gray-50 rounded-lg transition-colors">
              <div className="flex items-center gap-3">
                <Shield className="w-5 h-5 text-gray-600" />
                <span className="text-sm text-gray-700">Privacy Policy</span>
              </div>
              <ChevronRight className="w-4 h-4 text-gray-400" />
            </button>

            <button className="w-full flex items-center justify-between py-3 px-2 hover:bg-gray-50 rounded-lg transition-colors text-red-600">
              <div className="flex items-center gap-3">
                <LogOut className="w-5 h-5" />
                <span className="text-sm">Log Out</span>
              </div>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </motion.div>

        {/* App Info */}
        <div className="text-center text-xs text-gray-500 mb-6">
          <p>TN Train Tracker v1.0.0</p>
          <p className="mt-1">© 2025 Tamil Nadu Railways</p>
        </div>
      </div>
    </div>
  );
}
