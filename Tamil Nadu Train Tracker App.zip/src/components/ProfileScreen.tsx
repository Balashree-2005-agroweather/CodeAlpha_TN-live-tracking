import { motion } from 'motion/react';
import { User, Bookmark, Languages, Moon, Bell, Shield, HelpCircle, LogOut, ChevronRight } from 'lucide-react';

interface ProfileScreenProps {
  onBack: () => void;
}

export function ProfileScreen({ onBack }: ProfileScreenProps) {
  const savedTrains = [
    { number: '12635', name: 'Vaigai Express' },
    { number: '12621', name: 'Tamil Nadu Express' },
    { number: '16127', name: 'Guruvayur Express' },
  ];

  return (
    <div className="min-h-screen bg-gray-50 pb-20">
      {/* Header */}
      <div className="bg-gradient-to-r from-[#1A73E8] to-[#0D47A1] px-4 pt-12 pb-8">
        <motion.div
          initial={{ y: -20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.5 }}
        >
          <h1 className="text-white text-2xl mb-6">Profile</h1>
          
          {/* User Info Card */}
          <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-6 flex items-center gap-4">
            <div className="w-16 h-16 bg-white rounded-full flex items-center justify-center">
              <User className="text-[#1A73E8]" size={32} />
            </div>
            <div className="flex-1">
              <h2 className="text-white text-xl mb-1">Guest User</h2>
              <p className="text-blue-100 text-sm">Tamil Nadu, India</p>
            </div>
            <button className="text-white hover:bg-white/10 rounded-full p-2 transition-colors">
              <ChevronRight size={24} />
            </button>
          </div>
        </motion.div>
      </div>

      {/* Content */}
      <div className="px-4 py-6 space-y-6">
        {/* Saved Trains */}
        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.1, duration: 0.5 }}
          className="bg-white rounded-2xl shadow-md overflow-hidden"
        >
          <div className="p-4 border-b border-gray-100 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Bookmark className="text-[#1A73E8]" size={20} />
              <h3 className="text-gray-900">Saved Trains</h3>
            </div>
            <span className="text-sm text-gray-500">{savedTrains.length}</span>
          </div>
          <div className="divide-y divide-gray-100">
            {savedTrains.map((train, index) => (
              <button
                key={index}
                className="w-full p-4 flex items-center justify-between hover:bg-gray-50 transition-colors"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#1A73E8" strokeWidth="2">
                      <rect x="3" y="8" width="18" height="12" rx="2"/>
                      <path d="M3 12h18M7 8V5a2 2 0 0 1 2-2h6a2 2 0 0 1 2 2v3"/>
                      <circle cx="8" cy="18" r="1"/>
                      <circle cx="16" cy="18" r="1"/>
                    </svg>
                  </div>
                  <div className="text-left">
                    <div className="text-sm text-gray-900">{train.number}</div>
                    <div className="text-xs text-gray-500">{train.name}</div>
                  </div>
                </div>
                <ChevronRight className="text-gray-400" size={20} />
              </button>
            ))}
          </div>
        </motion.div>

        {/* Settings */}
        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.2, duration: 0.5 }}
          className="bg-white rounded-2xl shadow-md overflow-hidden"
        >
          <div className="p-4 border-b border-gray-100">
            <h3 className="text-gray-900">Settings</h3>
          </div>
          
          {/* Language */}
          <button className="w-full p-4 flex items-center justify-between hover:bg-gray-50 transition-colors border-b border-gray-100">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
                <Languages className="text-purple-600" size={20} />
              </div>
              <div className="text-left">
                <div className="text-sm text-gray-900">Language</div>
                <div className="text-xs text-gray-500">English / தமிழ்</div>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-sm text-gray-600">English</span>
              <ChevronRight className="text-gray-400" size={20} />
            </div>
          </button>

          {/* Dark Mode */}
          <div className="p-4 flex items-center justify-between border-b border-gray-100">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-indigo-100 rounded-lg flex items-center justify-center">
                <Moon className="text-indigo-600" size={20} />
              </div>
              <div className="text-left">
                <div className="text-sm text-gray-900">Dark Mode</div>
                <div className="text-xs text-gray-500">Enable dark theme</div>
              </div>
            </div>
            <label className="relative inline-block w-12 h-6">
              <input type="checkbox" className="peer sr-only" />
              <span className="absolute inset-0 bg-gray-200 rounded-full peer-checked:bg-[#1A73E8] transition-colors"/>
              <span className="absolute left-1 top-1 w-4 h-4 bg-white rounded-full transition-transform peer-checked:translate-x-6"/>
            </label>
          </div>

          {/* Notifications */}
          <button className="w-full p-4 flex items-center justify-between hover:bg-gray-50 transition-colors border-b border-gray-100">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-orange-100 rounded-lg flex items-center justify-center">
                <Bell className="text-orange-600" size={20} />
              </div>
              <div className="text-left">
                <div className="text-sm text-gray-900">Notifications</div>
                <div className="text-xs text-gray-500">Manage alerts</div>
              </div>
            </div>
            <ChevronRight className="text-gray-400" size={20} />
          </button>

          {/* Privacy */}
          <button className="w-full p-4 flex items-center justify-between hover:bg-gray-50 transition-colors">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                <Shield className="text-green-600" size={20} />
              </div>
              <div className="text-left">
                <div className="text-sm text-gray-900">Privacy & Security</div>
                <div className="text-xs text-gray-500">Data protection</div>
              </div>
            </div>
            <ChevronRight className="text-gray-400" size={20} />
          </button>
        </motion.div>

        {/* Support */}
        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.3, duration: 0.5 }}
          className="bg-white rounded-2xl shadow-md overflow-hidden"
        >
          <div className="p-4 border-b border-gray-100">
            <h3 className="text-gray-900">Support</h3>
          </div>
          
          <button className="w-full p-4 flex items-center justify-between hover:bg-gray-50 transition-colors border-b border-gray-100">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                <HelpCircle className="text-blue-600" size={20} />
              </div>
              <div className="text-left">
                <div className="text-sm text-gray-900">Help & FAQs</div>
                <div className="text-xs text-gray-500">Get assistance</div>
              </div>
            </div>
            <ChevronRight className="text-gray-400" size={20} />
          </button>

          <button className="w-full p-4 flex items-center justify-between hover:bg-gray-50 transition-colors">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gray-100 rounded-lg flex items-center justify-center">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#6B7280" strokeWidth="2">
                  <circle cx="12" cy="12" r="10"/>
                  <line x1="12" y1="16" x2="12" y2="12"/>
                  <line x1="12" y1="8" x2="12.01" y2="8"/>
                </svg>
              </div>
              <div className="text-left">
                <div className="text-sm text-gray-900">About</div>
                <div className="text-xs text-gray-500">Version 1.0.0</div>
              </div>
            </div>
            <ChevronRight className="text-gray-400" size={20} />
          </button>
        </motion.div>

        {/* Logout */}
        <motion.button
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.4, duration: 0.5 }}
          className="w-full bg-white rounded-2xl shadow-md p-4 flex items-center justify-center gap-3 text-red-600 hover:bg-red-50 transition-colors"
        >
          <LogOut size={20} />
          <span>Sign Out</span>
        </motion.button>

        {/* Footer */}
        <div className="text-center py-4">
          <p className="text-sm text-gray-500 mb-1">TN Train Tracker</p>
          <p className="text-xs text-gray-400">Made with ❤️ for Tamil Nadu</p>
        </div>
      </div>
    </div>
  );
}
