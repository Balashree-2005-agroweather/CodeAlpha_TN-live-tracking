import { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { ArrowLeft, MapPin, Clock, TrendingUp, Navigation, List, AlertCircle, Info } from 'lucide-react';
import { Screen, Train } from '../App';

interface LiveTrackingProps {
  train: Train | null;
  onNavigate: (screen: Screen) => void;
}

export function LiveTracking({ train, onNavigate }: LiveTrackingProps) {
  const [lastUpdated, setLastUpdated] = useState(new Date());
  const [animateSpeed, setAnimateSpeed] = useState(false);

  useEffect(() => {
    const interval = setInterval(() => {
      setLastUpdated(new Date());
      setAnimateSpeed(true);
      setTimeout(() => setAnimateSpeed(false), 500);
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  if (!train) {
    return (
      <div className="h-full flex items-center justify-center">
        <p className="text-gray-500">No train selected</p>
      </div>
    );
  }

  const currentStationIndex = train.stations.findIndex(s => s.status === 'current');
  const progress = currentStationIndex >= 0 
    ? (currentStationIndex / (train.stations.length - 1)) * 100 
    : 0;

  const timeAgo = Math.floor((new Date().getTime() - lastUpdated.getTime()) / 1000);

  return (
    <div className="h-full flex flex-col bg-gray-50 pb-20">
      {/* Header */}
      <div className="bg-white px-4 pt-12 pb-4 shadow-sm relative z-10">
        <div className="flex items-center justify-between mb-3">
          <button
            onClick={() => onNavigate('home')}
            className="text-gray-700 p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <ArrowLeft className="w-6 h-6" />
          </button>
          <span className="text-xs px-3 py-1 bg-green-100 text-green-700 rounded-full flex items-center gap-1">
            <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
            Live Tracking
          </span>
          <button
            onClick={() => onNavigate('timeline')}
            className="text-gray-700 p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <List className="w-6 h-6" />
          </button>
        </div>

        <div className="flex items-center gap-2 mb-1">
          <span className="text-[#1A73E8]">{train.number}</span>
          <span className="text-gray-400">•</span>
          <span className="text-gray-700">{train.name}</span>
        </div>
        <div className="text-xs text-gray-500">
          Updated {timeAgo}s ago
        </div>
      </div>

      {/* Map Section */}
      <div className="flex-1 relative bg-gradient-to-br from-blue-50 to-white">
        {/* Tamil Nadu Map Background */}
        <div className="absolute inset-0 flex items-center justify-center opacity-10">
          <svg width="300" height="400" viewBox="0 0 180 200" fill="none">
            <path
              d="M90 10 L130 30 L160 50 L170 80 L165 120 L155 160 L130 190 L90 195 L60 185 L40 160 L25 130 L20 90 L30 50 L60 20 Z"
              stroke="#1A73E8"
              strokeWidth="2"
              fill="rgba(26,115,232,0.05)"
            />
          </svg>
        </div>

        {/* Route Visualization */}
        <div className="absolute inset-0 flex items-center justify-center p-8">
          <div className="relative w-full max-w-xs">
            {/* Vertical railway line */}
            <div className="absolute left-1/2 top-0 bottom-0 w-1 -translate-x-1/2">
              <div className="absolute inset-0 bg-gray-300" />
              <motion.div
                className="absolute top-0 left-0 right-0 bg-gradient-to-b from-[#1A73E8] to-[#4CAF50]"
                initial={{ height: '0%' }}
                animate={{ height: `${progress}%` }}
                transition={{ duration: 1, ease: 'easeOut' }}
              />
            </div>

            {/* Stations */}
            <div className="relative space-y-16 py-8">
              {train.stations.slice(0, 5).map((station, index) => (
                <motion.div
                  key={station.name}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className={`relative flex items-center ${
                    index % 2 === 0 ? 'justify-start' : 'justify-end'
                  }`}
                >
                  {index % 2 === 0 ? (
                    <>
                      <div className={`mr-4 text-right ${
                        station.status === 'current' 
                          ? 'text-[#1A73E8]' 
                          : station.status === 'completed'
                          ? 'text-green-600'
                          : 'text-gray-400'
                      }`}>
                        <div className="text-sm">{station.name}</div>
                        <div className="text-xs">{station.arrivalTime}</div>
                      </div>
                      <div className={`w-4 h-4 rounded-full border-2 z-10 ${
                        station.status === 'current'
                          ? 'bg-[#1A73E8] border-[#1A73E8] shadow-lg shadow-blue-300'
                          : station.status === 'completed'
                          ? 'bg-green-500 border-green-500'
                          : 'bg-white border-gray-300'
                      }`} />
                    </>
                  ) : (
                    <>
                      <div className={`w-4 h-4 rounded-full border-2 z-10 ${
                        station.status === 'current'
                          ? 'bg-[#1A73E8] border-[#1A73E8] shadow-lg shadow-blue-300'
                          : station.status === 'completed'
                          ? 'bg-green-500 border-green-500'
                          : 'bg-white border-gray-300'
                      }`} />
                      <div className={`ml-4 text-left ${
                        station.status === 'current' 
                          ? 'text-[#1A73E8]' 
                          : station.status === 'completed'
                          ? 'text-green-600'
                          : 'text-gray-400'
                      }`}>
                        <div className="text-sm">{station.name}</div>
                        <div className="text-xs">{station.arrivalTime}</div>
                      </div>
                    </>
                  )}
                </motion.div>
              ))}
            </div>

            {/* Animated Train Marker */}
            <motion.div
              className="absolute left-1/2 -translate-x-1/2 z-20"
              style={{ top: `${progress}%` }}
              animate={{ scale: [1, 1.1, 1] }}
              transition={{ duration: 2, repeat: Infinity }}
            >
              <div className="w-12 h-12 bg-[#1A73E8] rounded-full flex items-center justify-center shadow-xl border-4 border-white">
                <Navigation className="w-6 h-6 text-white" />
              </div>
              <motion.div
                className="absolute -top-12 left-1/2 -translate-x-1/2 bg-white px-3 py-1.5 rounded-lg shadow-lg whitespace-nowrap"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
              >
                <div className="text-xs text-gray-500">Current Speed</div>
                <div className={`text-sm text-[#1A73E8] transition-all ${animateSpeed ? 'scale-110' : ''}`}>
                  {train.currentSpeed} km/h
                </div>
              </motion.div>
            </motion.div>
          </div>
        </div>
      </div>

      {/* Bottom Info Card */}
      <motion.div
        initial={{ y: 100 }}
        animate={{ y: 0 }}
        transition={{ duration: 0.5, ease: 'easeOut' }}
        className="bg-white rounded-t-3xl shadow-2xl p-6 relative z-10"
      >
        {/* Status Indicator */}
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <div className={`w-3 h-3 rounded-full ${
              train.status === 'On Time' ? 'bg-green-500' : 'bg-orange-500'
            } animate-pulse`} />
            <span className={`text-sm ${
              train.status === 'On Time' ? 'text-green-700' : 'text-orange-700'
            }`}>
              {train.status}
              {train.delay > 0 && ` • Delayed by ${train.delay} mins`}
            </span>
          </div>
          <button className="text-[#1A73E8] p-2">
            <Info className="w-5 h-5" />
          </button>
        </div>

        {/* Route Info */}
        <div className="mb-4">
          <div className="flex items-center justify-between text-sm mb-2">
            <span className="text-gray-600">{train.from}</span>
            <span className="text-gray-400">→</span>
            <span className="text-gray-600">{train.to}</span>
          </div>
          <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
            <motion.div
              className="h-full bg-gradient-to-r from-[#1A73E8] to-[#4CAF50]"
              initial={{ width: '0%' }}
              animate={{ width: `${progress}%` }}
              transition={{ duration: 1, ease: 'easeOut' }}
            />
          </div>
          <div className="text-xs text-gray-500 text-right mt-1">{Math.round(progress)}% completed</div>
        </div>

        {/* Key Stats */}
        <div className="grid grid-cols-3 gap-3">
          <div className="bg-blue-50 rounded-xl p-3">
            <div className="flex items-center gap-2 mb-1">
              <MapPin className="w-4 h-4 text-[#1A73E8]" />
              <span className="text-xs text-gray-600">Next Station</span>
            </div>
            <div className="text-sm text-gray-800">{train.nextStation}</div>
            <div className="text-xs text-gray-500 mt-1">{train.distanceRemaining} km</div>
          </div>

          <div className="bg-green-50 rounded-xl p-3">
            <div className="flex items-center gap-2 mb-1">
              <Clock className="w-4 h-4 text-green-600" />
              <span className="text-xs text-gray-600">ETA</span>
            </div>
            <div className="text-sm text-gray-800">{train.estimatedArrival}</div>
            <div className="text-xs text-gray-500 mt-1">Estimated</div>
          </div>

          <div className="bg-purple-50 rounded-xl p-3">
            <div className="flex items-center gap-2 mb-1">
              <TrendingUp className="w-4 h-4 text-purple-600" />
              <span className="text-xs text-gray-600">Speed</span>
            </div>
            <div className="text-sm text-gray-800">{train.currentSpeed} km/h</div>
            <div className="text-xs text-gray-500 mt-1">Current</div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="grid grid-cols-2 gap-3 mt-4">
          <button
            onClick={() => onNavigate('timeline')}
            className="py-3 px-4 bg-[#1A73E8] text-white rounded-xl flex items-center justify-center gap-2 hover:bg-[#1557b0] transition-colors"
          >
            <List className="w-4 h-4" />
            Station List
          </button>
          <button
            onClick={() => onNavigate('alerts')}
            className="py-3 px-4 bg-gray-100 text-gray-700 rounded-xl flex items-center justify-center gap-2 hover:bg-gray-200 transition-colors"
          >
            <AlertCircle className="w-4 h-4" />
            Alerts
          </button>
        </div>
      </motion.div>
    </div>
  );
}
