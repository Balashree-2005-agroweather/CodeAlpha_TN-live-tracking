import { useState } from 'react';
import { SplashScreen } from './components/SplashScreen';
import { LoginScreen } from './components/LoginScreen';
import { HomeScreen } from './components/HomeScreen';
import { SearchResults } from './components/SearchResults';
import { LiveTrackingScreen } from './components/LiveTrackingScreen';
import { StationTimeline } from './components/StationTimeline';
import { Alerts } from './components/Alerts';
import { ProfileScreen } from './components/ProfileScreen';

export type Screen = 'splash' | 'login' | 'home' | 'search' | 'tracking' | 'timeline' | 'alerts' | 'profile';

export interface Train {
  number: string;
  name: string;
  from: string;
  to: string;
  status: 'On Time' | 'Delayed';
  delay?: number;
  currentSpeed: number;
  nextStation: string;
  distanceRemaining: number;
  eta: string;
  currentLat: number;
  currentLng: number;
}

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<Screen>('splash');
  const [selectedTrain, setSelectedTrain] = useState<Train | null>(null);
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  // Auto-transition from splash to login after 2.5 seconds
  if (currentScreen === 'splash') {
    setTimeout(() => setCurrentScreen('login'), 2500);
  }

  const handleLogin = () => {
    setIsLoggedIn(true);
    setCurrentScreen('home');
  };

  const handleTrainSelect = (train: Train) => {
    setSelectedTrain(train);
    setCurrentScreen('tracking');
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Mobile Container */}
      <div className="max-w-md mx-auto bg-white shadow-2xl min-h-screen relative">
        {currentScreen === 'splash' && <SplashScreen />}
        {currentScreen === 'login' && <LoginScreen onLogin={handleLogin} />}
        {currentScreen === 'home' && (
          <HomeScreen 
            onSearch={() => setCurrentScreen('search')}
            onNavigate={setCurrentScreen}
            onTrainSelect={handleTrainSelect}
          />
        )}
        {currentScreen === 'search' && (
          <SearchResults 
            onBack={() => setCurrentScreen('home')}
            onTrainSelect={handleTrainSelect}
          />
        )}
        {currentScreen === 'tracking' && selectedTrain && (
          <LiveTrackingScreen 
            train={selectedTrain}
            onBack={() => setCurrentScreen('search')}
            onViewTimeline={() => setCurrentScreen('timeline')}
          />
        )}
        {currentScreen === 'timeline' && selectedTrain && (
          <StationTimeline 
            train={selectedTrain}
            onBack={() => setCurrentScreen('tracking')}
          />
        )}
        {currentScreen === 'alerts' && (
          <Alerts onBack={() => setCurrentScreen('home')} />
        )}
        {currentScreen === 'profile' && (
          <ProfileScreen onBack={() => setCurrentScreen('home')} />
        )}

        {/* Bottom Navigation - Only show on main screens */}
        {['home', 'alerts', 'profile'].includes(currentScreen) && (
          <div className="fixed bottom-0 left-0 right-0 max-w-md mx-auto bg-white border-t border-gray-200 px-4 py-3 flex justify-around items-center">
            <button 
              onClick={() => setCurrentScreen('home')}
              className={`flex flex-col items-center gap-1 ${currentScreen === 'home' ? 'text-[#1A73E8]' : 'text-gray-500'}`}
            >
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>
                <polyline points="9 22 9 12 15 12 15 22"/>
              </svg>
              <span className="text-xs">Home</span>
            </button>
            <button 
              onClick={() => setCurrentScreen('alerts')}
              className={`flex flex-col items-center gap-1 relative ${currentScreen === 'alerts' ? 'text-[#1A73E8]' : 'text-gray-500'}`}
            >
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/>
                <path d="M13.73 21a2 2 0 0 1-3.46 0"/>
              </svg>
              <span className="text-xs">Alerts</span>
              <span className="absolute -top-1 right-3 bg-red-500 text-white text-[10px] rounded-full w-4 h-4 flex items-center justify-center">3</span>
            </button>
            <button 
              onClick={() => setCurrentScreen('profile')}
              className={`flex flex-col items-center gap-1 ${currentScreen === 'profile' ? 'text-[#1A73E8]' : 'text-gray-500'}`}
            >
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>
                <circle cx="12" cy="7" r="4"/>
              </svg>
              <span className="text-xs">Profile</span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
}